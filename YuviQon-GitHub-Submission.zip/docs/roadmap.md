# MVP Roadmap

## Phase 1 — Validation
- Interview/contact boutique consulting firms
- Identify repetitive research-heavy tasks
- Test sample deliverables
- Secure first paid pilot

## Phase 2 — Prototype
- Research task decomposition
- Retrieval/search layer
- Structured extraction
- Evidence tracking
- Human review interface

## Phase 3 — Pilot
- Run real consulting workflows
- Measure time saved and output quality
- Improve prompts, schemas and retrieval
- Establish repeatable delivery process

## Phase 4 — MVP
- Multi-project workspace
- Research database
- Competitor tracking
- Export/report generation
- Usage and quality analytics
