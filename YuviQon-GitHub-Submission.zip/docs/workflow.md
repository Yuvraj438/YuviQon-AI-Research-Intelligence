# Initial Workflow Specification

1. User enters a consulting research question.
2. System decomposes the question into research tasks.
3. Relevant sources are discovered and retrieved.
4. Information is extracted into a predefined schema.
5. Entities/competitors are normalized and matched.
6. Data is stored in a structured research table.
7. AI generates comparisons and candidate insights.
8. Evidence/source links are attached to findings.
9. Human reviewer checks important claims.
10. Final output is packaged as a report/table/presentation-ready summary.

This is a product design concept, not a claim of an existing working system.
